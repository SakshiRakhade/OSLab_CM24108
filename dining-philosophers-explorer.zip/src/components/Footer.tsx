import React from 'react';
import { Github, Mail, Linkedin, GraduationCap } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-slate-50 border-t border-slate-200 pt-12 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="space-y-4">
            <h3 className="font-display font-bold text-xl text-slate-900">
              OS<span className="text-primary">Sync</span>
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed max-w-xs">
              An educational platform dedicated to simplifying complex Operating System concepts through interactive visualizations.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-slate-900">Project Info</h4>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>Subject: Operating Systems</li>
              <li>Topic: Dining Philosophers Problem</li>
              <li>College: S.B. Jain Institute of Technology Management and Research</li>
              <li>Academic Year: 2025-26</li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-slate-900">Developer</h4>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <GraduationCap className="w-4 h-4 text-primary" />
                <span>Sakshi Rakhade</span>
              </div>
              <div className="flex gap-4">
                <a href="#" className="p-2 bg-white rounded-full shadow-sm hover:text-primary transition-colors border border-slate-100">
                  <Github className="w-4 h-4" />
                </a>
                <a href="mailto:sakshi14506@gmail.com" className="p-2 bg-white rounded-full shadow-sm hover:text-primary transition-colors border border-slate-100">
                  <Mail className="w-4 h-4" />
                </a>
                <a href="#" className="p-2 bg-white rounded-full shadow-sm hover:text-primary transition-colors border border-slate-100">
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-xs">
            © 2026 OS Sync Project. Built for educational purposes.
          </p>
          <div className="flex gap-6 text-xs text-slate-500">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Use</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
