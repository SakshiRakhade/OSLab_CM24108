import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { LucideIcon } from 'lucide-react';

interface PageWrapperProps {
  children: React.ReactNode;
  className?: string;
}

export const PageWrapper = ({ children, className }: PageWrapperProps) => {
  return (
    <motion.main
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className={cn('pt-24 pb-16 px-4 max-w-7xl mx-auto', className)}
    >
      {children}
    </motion.main>
  );
};

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  className?: string;
}

export const SectionHeader = ({ title, subtitle, className }: SectionHeaderProps) => {
  return (
    <div className={cn('mb-12 text-center md:text-left', className)}>
      <motion.h1
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="font-display font-bold text-4xl md:text-5xl text-slate-900 mb-4 tracking-tight"
      >
        {title}
      </motion.h1>
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="text-slate-600 text-lg md:text-xl max-w-2xl"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
};

interface ContentCardProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  className?: string;
  delay?: number;
  key?: React.Key;
}

export const ContentCard = ({ title, description, icon: Icon, className, delay = 0 }: ContentCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className={cn(
        'p-8 rounded-[32px] bg-white/60 backdrop-blur-md border border-white/50 shadow-sm hover:shadow-md transition-all group',
        className
      )}
    >
      {Icon && (
        <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-sm shadow-primary/10">
          <Icon className="w-7 h-7 text-primary" />
        </div>
      )}
      <h3 className="font-bold text-xl text-slate-900 mb-3">{title}</h3>
      <p className="text-slate-600 leading-relaxed text-sm">{description}</p>
    </motion.div>
  );
};
