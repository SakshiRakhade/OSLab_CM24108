export type PhilosopherState = 'Thinking' | 'Hungry' | 'Eating';

export interface Philosopher {
  id: number;
  name: string;
  state: PhilosopherState;
  leftForkId: number;
  rightForkId: number;
}

export interface Fork {
  id: number;
  isHeld: boolean;
  heldBy: number | null;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "What is the primary problem illustrated by the Dining Philosophers problem?",
    options: [
      "Memory management",
      "Process scheduling",
      "Resource synchronization and deadlock",
      "Network latency"
    ],
    correctAnswer: 2,
    explanation: "The Dining Philosophers problem is a classic example used to illustrate issues in concurrent algorithm design, specifically resource synchronization and potential deadlock."
  },
  {
    id: 2,
    question: "How many forks are needed for a philosopher to eat?",
    options: [
      "One",
      "Two",
      "Three",
      "Five"
    ],
    correctAnswer: 1,
    explanation: "In the standard problem statement, each philosopher needs two forks (the one on their left and the one on their right) to eat."
  },
  {
    id: 3,
    question: "What occurs when every philosopher picks up their left fork simultaneously?",
    options: [
      "They all start eating",
      "Starvation",
      "Deadlock",
      "Context switching"
    ],
    correctAnswer: 2,
    explanation: "If every philosopher picks up their left fork, no one can pick up their right fork, leading to a circular wait condition known as deadlock."
  },
  {
    id: 4,
    question: "Which of these is a valid solution to prevent deadlock in the Dining Philosophers problem?",
    options: [
      "Letting all philosophers pick up forks at once",
      "Using a resource hierarchy (asymmetric picking)",
      "Adding more philosophers",
      "Removing all forks"
    ],
    correctAnswer: 1,
    explanation: "A resource hierarchy solution (e.g., one philosopher picks up the right fork first) breaks the circular wait condition."
  },
  {
    id: 5,
    question: "What is 'Starvation' in the context of this problem?",
    options: [
      "When a philosopher runs out of food",
      "When a philosopher is perpetually denied access to forks",
      "When the program crashes",
      "When the CPU is idle"
    ],
    correctAnswer: 1,
    explanation: "Starvation occurs when a philosopher is repeatedly unable to acquire both forks and thus never gets to eat, even if the system as a whole is not deadlocked."
  }
];
