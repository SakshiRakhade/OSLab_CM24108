import React from 'react';
import { CheckCircle2, Code, ShieldCheck, Zap, UserCheck, ListOrdered } from 'lucide-react';
import { PageWrapper, SectionHeader, ContentCard } from '../components/Common';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export const Solutions = () => {
  const solutions = [
    {
      icon: ListOrdered,
      title: "Resource Hierarchy",
      description: "Assign an order to the forks and require philosophers to pick up the lower-numbered fork first.",
      details: "This breaks the circular wait condition by introducing an asymmetry.",
      color: "bg-pastel-lavender/40"
    },
    {
      icon: UserCheck,
      title: "The Waiter Solution",
      description: "An arbitrator (waiter) controls access to the forks and only allows a philosopher to pick up forks if both are available.",
      details: "Centralized control ensures no deadlock can occur.",
      color: "bg-pastel-blue/40"
    },
    {
      icon: ShieldCheck,
      title: "Semaphore Solution",
      description: "Use semaphores to represent forks and a mutex to control access to the critical section.",
      details: "Classic OS synchronization primitive used for mutual exclusion.",
      color: "bg-pastel-mint/40"
    },
    {
      icon: Zap,
      title: "Chandy/Misra Solution",
      description: "A distributed solution where philosophers request forks from neighbors using a priority system.",
      details: "Avoids centralized control and is more scalable for large systems.",
      color: "bg-pastel-peach/40"
    }
  ];

  const codeSnippet = `
// Semaphore Solution Pseudocode
semaphore fork[5] = {1, 1, 1, 1, 1};
semaphore mutex = 1;

void philosopher(int i) {
  while (true) {
    think();
    wait(mutex);
    wait(fork[i]);
    wait(fork[(i + 1) % 5]);
    signal(mutex);
    eat();
    signal(fork[i]);
    signal(fork[(i + 1) % 5]);
  }
}
  `;

  return (
    <div className="min-h-screen pastel-gradient-2">
      <PageWrapper>
        <SectionHeader
          title="Effective Solutions"
          subtitle="Various strategies have been developed to prevent deadlock and ensure fairness."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {solutions.map((sol, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={cn(
                "p-8 rounded-[40px] glass border border-white/50 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row gap-8",
                sol.color
              )}
            >
              <div className="w-20 h-20 bg-white/60 backdrop-blur-md rounded-3xl flex items-center justify-center shrink-0 shadow-sm">
                <sol.icon className="w-10 h-10 text-primary" />
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="font-bold text-2xl text-slate-900 mb-3">{sol.title}</h3>
                <p className="text-slate-600 text-sm mb-6 leading-relaxed">{sol.description}</p>
                <div className="inline-flex items-center gap-2 text-xs font-bold text-primary bg-white/80 px-4 py-2 rounded-full w-fit shadow-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  {sol.details}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="glass rounded-[48px] p-8 md:p-16 border border-white/50 shadow-2xl overflow-hidden relative">
          <div className="absolute top-0 right-0 w-full h-full opacity-5 pointer-events-none">
            <div className="absolute top-10 right-10 w-64 h-64 bg-primary rounded-full blur-3xl" />
          </div>

          <div className="flex items-center gap-5 mb-12 relative z-10">
            <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center text-white shadow-xl">
              <Code className="w-7 h-7" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900">Implementation Logic</h2>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 relative z-10">
            <div className="space-y-10">
              <p className="text-slate-600 leading-relaxed text-lg">
                The Semaphore solution uses a mutex to ensure that only one philosopher can attempt to pick up forks at a time, 
                preventing the circular wait condition.
              </p>
              <div className="space-y-6">
                {[
                  "Initialize 5 semaphores for 5 forks.",
                  "Use a mutex to protect the fork-picking process.",
                  "Philosopher waits for both forks before eating."
                ].map((text, i) => (
                  <div key={i} className="flex items-center gap-5 group">
                    <div className="w-10 h-10 rounded-2xl bg-white shadow-sm flex items-center justify-center text-primary font-bold group-hover:bg-primary group-hover:text-white transition-all">
                      {i + 1}
                    </div>
                    <p className="text-slate-700 font-medium">{text}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900 rounded-[32px] p-8 font-mono text-sm overflow-x-auto border border-slate-800 shadow-2xl">
              <pre className="text-blue-300 leading-relaxed">
                {codeSnippet}
              </pre>
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
