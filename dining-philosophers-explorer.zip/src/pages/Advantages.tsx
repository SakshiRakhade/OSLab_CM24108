import React from 'react';
import { CheckCircle2, AlertCircle, ShieldCheck, Zap, Target, Layers } from 'lucide-react';
import { PageWrapper, SectionHeader, ContentCard } from '../components/Common';
import { motion } from 'motion/react';

export const Advantages = () => {
  return (
    <div className="min-h-screen pastel-gradient-1">
      <PageWrapper>
        <SectionHeader
          title="Advantages & Challenges"
          subtitle="Understanding this problem provides deep insights into concurrent programming and system design."
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Advantages */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-pastel-mint/60 backdrop-blur-md rounded-[24px] flex items-center justify-center text-emerald-700 shadow-sm border border-white/50">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Key Advantages</h2>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              {[
                { icon: ShieldCheck, title: "Deadlock Prevention", desc: "Provides a framework for identifying and avoiding circular wait conditions.", color: "bg-pastel-mint/30" },
                { icon: Zap, title: "Resource Optimization", desc: "Helps in designing systems that maximize resource utilization while maintaining fairness.", color: "bg-pastel-blue/30" },
                { icon: Target, title: "Algorithm Design", desc: "Serves as a benchmark for testing new synchronization primitives and algorithms.", color: "bg-pastel-lavender/30" }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className={`p-8 ${item.color} backdrop-blur-md rounded-[32px] border border-white/50 shadow-sm flex gap-6 hover:shadow-md transition-all duration-300`}
                >
                  <div className="w-12 h-12 bg-white/60 rounded-2xl flex items-center justify-center shrink-0 shadow-sm">
                    <item.icon className="w-6 h-6 text-slate-700" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">{item.title}</h4>
                    <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Challenges */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-pastel-peach/60 backdrop-blur-md rounded-[24px] flex items-center justify-center text-orange-700 shadow-sm border border-white/50">
                <AlertCircle className="w-7 h-7" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Implementation Challenges</h2>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              {[
                { icon: Layers, title: "Complexity", desc: "Implementing efficient solutions without causing significant overhead is difficult.", color: "bg-pastel-peach/30" },
                { icon: AlertCircle, title: "Scalability", desc: "Centralized solutions (like the waiter) can become bottlenecks in large systems.", color: "bg-pastel-pink/30" },
                { icon: ShieldCheck, title: "Fairness", desc: "Ensuring that no philosopher is perpetually denied access (starvation) is a major hurdle.", color: "bg-pastel-lavender/30" }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className={`p-8 ${item.color} backdrop-blur-md rounded-[32px] border border-white/50 shadow-sm flex gap-6 hover:shadow-md transition-all duration-300`}
                >
                  <div className="w-12 h-12 bg-white/60 rounded-2xl flex items-center justify-center shrink-0 shadow-sm">
                    <item.icon className="w-6 h-6 text-slate-700" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">{item.title}</h4>
                    <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
