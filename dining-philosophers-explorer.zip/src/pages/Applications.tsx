import React from 'react';
import { Network, Database, Cpu, Globe, Share2, Server } from 'lucide-react';
import { PageWrapper, SectionHeader, ContentCard } from '../components/Common';

export const Applications = () => {
  const apps = [
    {
      icon: Network,
      title: "Network Routing",
      description: "Managing shared bandwidth and preventing circular wait in packet transmission across multiple nodes.",
      color: "bg-pastel-lavender/40"
    },
    {
      icon: Database,
      title: "Database Transactions",
      description: "Ensuring data consistency when multiple transactions attempt to lock the same set of records.",
      color: "bg-pastel-blue/40"
    },
    {
      icon: Cpu,
      title: "Multi-core Processing",
      description: "Allocating shared cache and memory resources among different CPU cores without causing system hangs.",
      color: "bg-pastel-mint/40"
    },
    {
      icon: Globe,
      title: "Distributed Systems",
      description: "Coordinating resource access across geographically dispersed servers in a cloud environment.",
      color: "bg-pastel-peach/40"
    },
    {
      icon: Share2,
      title: "File System Locking",
      description: "Managing concurrent access to files where multiple processes need to read or write simultaneously.",
      color: "bg-pastel-pink/40"
    },
    {
      icon: Server,
      title: "Print Spooling",
      description: "Handling multiple print requests for a single printer resource in a local area network.",
      color: "bg-pastel-lavender/40"
    }
  ];

  return (
    <div className="min-h-screen pastel-gradient-3">
      <PageWrapper>
        <SectionHeader
          title="Real-Life Applications"
          subtitle="The principles derived from the Dining Philosophers problem are fundamental to modern computing systems."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {apps.map((app, i) => (
            <ContentCard
              key={i}
              icon={app.icon}
              title={app.title}
              description={app.description}
              delay={i * 0.1}
              className={app.color}
            />
          ))}
        </div>
      </PageWrapper>
    </div>
  );
};
