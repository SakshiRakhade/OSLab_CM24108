import React from 'react';
import { AlertTriangle, RefreshCw, Layers, ShieldAlert } from 'lucide-react';
import { PageWrapper, SectionHeader, ContentCard } from '../components/Common';
import { motion } from 'motion/react';

export const Issues = () => {
  return (
    <div className="min-h-screen pastel-gradient-1">
      <PageWrapper>
        <SectionHeader
          title="Key Issues & Challenges"
          subtitle="Without proper synchronization, the Dining Philosophers system can fail in several critical ways."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          <ContentCard
            icon={AlertTriangle}
            title="Deadlock"
            description="A state where every philosopher has picked up their left fork and is waiting for their right fork. No one can proceed."
            className="bg-pastel-pink/30 border-red-100"
          />
          <ContentCard
            icon={RefreshCw}
            title="Starvation"
            description="When a philosopher is perpetually denied access to forks because their neighbors are always eating."
            className="bg-pastel-peach/30 border-orange-100"
          />
          <ContentCard
            icon={Layers}
            title="Resource Contention"
            description="High competition for limited resources (forks) leads to performance degradation and latency."
            className="bg-pastel-blue/30 border-blue-100"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-10">
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 bg-red-100 rounded-[20px] flex items-center justify-center text-red-600 shadow-sm">
                <ShieldAlert className="w-7 h-7" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900">Understanding Deadlock</h2>
            </div>
            
            <p className="text-slate-600 leading-relaxed text-lg">
              Deadlock occurs when four conditions are met simultaneously:
            </p>
            
            <ul className="space-y-5">
              {[
                { title: "Mutual Exclusion", desc: "Only one philosopher can hold a fork at a time." },
                { title: "Hold and Wait", desc: "A philosopher holding one fork waits for another." },
                { title: "No Preemption", desc: "Forks cannot be forcibly taken from a philosopher." },
                { title: "Circular Wait", desc: "A chain of philosophers exists where each waits for a fork held by the next." }
              ].map((item, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-start gap-5 p-6 glass rounded-[28px] border border-white/50 shadow-sm group hover:shadow-md transition-all"
                >
                  <div className="w-8 h-8 rounded-xl bg-red-50 flex items-center justify-center text-red-500 font-bold text-sm mt-1 group-hover:bg-red-500 group-hover:text-white transition-colors">
                    {i+1}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">{item.title}</h4>
                    <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </motion.li>
              ))}
            </ul>
          </div>

          <div className="bg-white/40 backdrop-blur-sm rounded-[48px] p-10 flex items-center justify-center border border-white/50 shadow-inner">
            <svg viewBox="0 0 400 400" className="w-full max-w-sm h-auto drop-shadow-2xl">
              {/* Table */}
              <circle cx="200" cy="200" r="100" fill="white" stroke="#ef4444" strokeWidth="4" strokeDasharray="12 6" className="animate-pulse" />
              
              {/* Deadlock Visualization */}
              {[0, 72, 144, 216, 288].map((angle, i) => {
                const px = 200 + 140 * Math.cos((angle - 90) * (Math.PI / 180));
                const py = 200 + 140 * Math.sin((angle - 90) * (Math.PI / 180));
                const fx = 200 + 110 * Math.cos((angle - 90) * (Math.PI / 180));
                const fy = 200 + 110 * Math.sin((angle - 90) * (Math.PI / 180));
                
                return (
                  <g key={i}>
                    {/* Philosopher holding a fork */}
                    <circle cx={px} cy={py} r="25" fill="#ef4444" />
                    <motion.path
                      d={`M ${px} ${py} L ${fx} ${fy}`}
                      stroke="#ef4444"
                      strokeWidth="4"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: 1 }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                    {/* Waiting arrow */}
                    <motion.path
                      d={`M ${px} ${py} Q 200 200 ${200 + 140 * Math.cos((angle + 72 - 90) * (Math.PI / 180))} ${200 + 140 * Math.sin((angle + 72 - 90) * (Math.PI / 180))}`}
                      fill="none"
                      stroke="#ef4444"
                      strokeWidth="2"
                      strokeDasharray="4 4"
                      opacity="0.5"
                    />
                  </g>
                );
              })}
              <text x="200" y="205" textAnchor="middle" className="font-bold text-xl fill-red-600">DEADLOCK</text>
            </svg>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
