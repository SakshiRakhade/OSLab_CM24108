import React, { useState } from 'react';
import { CheckCircle2, XCircle, RotateCcw, Award, HelpCircle } from 'lucide-react';
import { PageWrapper, SectionHeader } from '../components/Common';
import { motion, AnimatePresence } from 'motion/react';
import { QUIZ_QUESTIONS } from '../types';
import { cn } from '../lib/utils';

export const Quiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleOptionClick = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    if (index === QUIZ_QUESTIONS[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < QUIZ_QUESTIONS.length) {
      setCurrentQuestion(nextQuestion);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowScore(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedOption(null);
    setIsAnswered(false);
  };

  return (
    <div className="min-h-screen pastel-gradient-2">
      <PageWrapper>
        <SectionHeader
          title="Knowledge Check"
          subtitle="Test your understanding of the Dining Philosophers problem and its solutions."
        />

        <div className="max-w-3xl mx-auto">
          <AnimatePresence mode="wait">
            {!showScore ? (
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white/60 backdrop-blur-md rounded-[40px] p-8 md:p-12 border border-white/50 shadow-xl"
              >
                <div className="flex justify-between items-center mb-10">
                  <div className="px-6 py-2 bg-pastel-blue/40 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm border border-white/50">
                    Question {currentQuestion + 1} of {QUIZ_QUESTIONS.length}
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <HelpCircle className="w-5 h-5" />
                    <span className="text-xs font-bold">Multiple Choice</span>
                  </div>
                </div>

                <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-10 leading-tight tracking-tight">
                  {QUIZ_QUESTIONS[currentQuestion].question}
                </h2>

                <div className="space-y-4 mb-12">
                  {QUIZ_QUESTIONS[currentQuestion].options.map((option, index) => {
                    const isCorrect = index === QUIZ_QUESTIONS[currentQuestion].correctAnswer;
                    const isSelected = index === selectedOption;
                    
                    let buttonClass = "w-full p-6 rounded-[24px] border-2 text-left transition-all flex items-center justify-between group shadow-sm ";
                    if (!isAnswered) {
                      buttonClass += "border-white/50 bg-white/40 hover:border-pastel-blue hover:bg-white/80 text-slate-700";
                    } else if (isCorrect) {
                      buttonClass += "border-emerald-400 bg-emerald-50/80 text-emerald-800";
                    } else if (isSelected && !isCorrect) {
                      buttonClass += "border-rose-400 bg-rose-50/80 text-rose-800";
                    } else {
                      buttonClass += "border-white/20 text-slate-400 opacity-50";
                    }

                    return (
                      <button
                        key={index}
                        onClick={() => handleOptionClick(index)}
                        disabled={isAnswered}
                        className={buttonClass}
                      >
                        <span className="font-semibold text-lg">{option}</span>
                        {isAnswered && isCorrect && <CheckCircle2 className="w-6 h-6 text-emerald-500" />}
                        {isAnswered && isSelected && !isCorrect && <XCircle className="w-6 h-6 text-rose-500" />}
                      </button>
                    );
                  })}
                </div>

                {isAnswered && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-10 p-8 bg-white/40 backdrop-blur-sm rounded-[24px] border border-white/50 shadow-inner"
                  >
                    <p className="text-slate-700 leading-relaxed italic">
                      <span className="font-bold text-slate-900 not-italic mr-2">Explanation:</span>
                      {QUIZ_QUESTIONS[currentQuestion].explanation}
                    </p>
                  </motion.div>
                )}

                <div className="flex justify-end">
                  <button
                    onClick={handleNextQuestion}
                    disabled={!isAnswered}
                    className={cn(
                      "px-12 py-5 rounded-[24px] font-bold transition-all flex items-center gap-2 shadow-lg",
                      isAnswered 
                        ? "bg-slate-900 text-white hover:bg-slate-800 hover:scale-105" 
                        : "bg-white/40 text-slate-400 cursor-not-allowed border border-white/50"
                    )}
                  >
                    {currentQuestion === QUIZ_QUESTIONS.length - 1 ? 'Finish Quiz' : 'Next Question'}
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white/60 backdrop-blur-md rounded-[40px] p-12 md:p-16 border border-white/50 shadow-xl text-center"
              >
                <div className="w-28 h-28 bg-pastel-lavender/40 rounded-full flex items-center justify-center mx-auto mb-10 shadow-sm border border-white/50">
                  <Award className="w-14 h-14 text-indigo-600" />
                </div>
                <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4 tracking-tight">Quiz Completed!</h2>
                <p className="text-slate-600 mb-12 text-xl">
                  You scored <span className="text-indigo-600 font-bold">{score}</span> out of <span className="font-bold">{QUIZ_QUESTIONS.length}</span>
                </p>
                
                <div className="w-full bg-white/40 h-6 rounded-full mb-16 overflow-hidden border border-white/50 shadow-inner p-1">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(score / QUIZ_QUESTIONS.length) * 100}%` }}
                    className="h-full bg-gradient-to-r from-pastel-blue to-pastel-lavender rounded-full shadow-sm"
                  />
                </div>

                <button
                  onClick={resetQuiz}
                  className="px-12 py-5 bg-slate-900 text-white rounded-[24px] font-bold flex items-center gap-3 hover:bg-slate-800 transition-all shadow-xl mx-auto hover:scale-105"
                >
                  <RotateCcw className="w-6 h-6" />
                  Try Again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </PageWrapper>
    </div>
  );
};
