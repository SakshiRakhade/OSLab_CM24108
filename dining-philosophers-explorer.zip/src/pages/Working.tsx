import React from 'react';
import { Brain, Coffee, UtensilsCrossed, ArrowRightCircle } from 'lucide-react';
import { PageWrapper, SectionHeader, ContentCard } from '../components/Common';
import { motion } from 'motion/react';

export const Working = () => {
  const steps = [
    {
      icon: Brain,
      title: "Thinking State",
      description: "Initially, all philosophers are thinking. They don't interact with the forks or each other.",
      color: "bg-pastel-blue/50 text-blue-600"
    },
    {
      icon: Coffee,
      title: "Hungry State",
      description: "A philosopher becomes hungry and tries to acquire the two forks adjacent to them.",
      color: "bg-pastel-peach/50 text-orange-600"
    },
    {
      icon: UtensilsCrossed,
      title: "Eating State",
      description: "If both forks are available, the philosopher picks them up and eats for a while.",
      color: "bg-pastel-mint/50 text-emerald-600"
    },
    {
      icon: Brain,
      title: "Return to Thinking",
      description: "After eating, the philosopher puts down both forks and returns to the thinking state.",
      color: "bg-pastel-lavender/50 text-purple-600"
    }
  ];

  return (
    <div className="min-h-screen pastel-gradient-3">
      <PageWrapper>
        <SectionHeader
          title="How it Works"
          subtitle="The lifecycle of a philosopher is a continuous loop of three distinct states."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-[40px] glass border border-white/50 shadow-sm hover:shadow-md transition-all text-center group"
            >
              <div className={`w-20 h-20 ${step.color} rounded-3xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform shadow-sm`}>
                <step.icon className="w-10 h-10" />
              </div>
              <h3 className="font-bold text-xl text-slate-900 mb-4">{step.title}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">{step.description}</p>
            </motion.div>
          ))}
        </div>

        <div className="glass rounded-[48px] p-8 md:p-16 border border-white/50 shadow-2xl overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
            <div className="absolute top-10 left-10 w-48 h-48 border-8 border-primary rounded-full" />
            <div className="absolute bottom-10 right-10 w-80 h-80 border-8 border-secondary rounded-full" />
          </div>

          <div className="relative z-10 max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-12 text-slate-900">The Lifecycle Flowchart</h2>
            
            <div className="flex flex-col items-center gap-10">
              <div className="px-10 py-5 bg-white/60 backdrop-blur-md rounded-2xl border border-white/80 w-full max-w-xs shadow-sm">
                <span className="font-bold text-slate-700">Thinking</span>
              </div>
              <ArrowRightCircle className="w-10 h-10 text-primary rotate-90 opacity-50" />
              <div className="px-10 py-5 bg-white/60 backdrop-blur-md rounded-2xl border border-white/80 w-full max-w-xs shadow-sm">
                <span className="font-bold text-slate-700">Hungry</span>
              </div>
              <ArrowRightCircle className="w-10 h-10 text-primary rotate-90 opacity-50" />
              <div className="px-10 py-5 bg-white/60 backdrop-blur-md rounded-2xl border border-white/80 w-full max-w-xs shadow-sm">
                <span className="font-bold text-slate-700">Wait for Forks</span>
              </div>
              <ArrowRightCircle className="w-10 h-10 text-primary rotate-90 opacity-50" />
              <div className="px-10 py-5 bg-primary rounded-2xl shadow-xl shadow-primary/20 w-full max-w-xs">
                <span className="font-bold text-white">Eating</span>
              </div>
              <ArrowRightCircle className="w-10 h-10 text-primary rotate-90 opacity-50" />
              <div className="px-10 py-5 bg-white/60 backdrop-blur-md rounded-2xl border border-white/80 w-full max-w-xs shadow-sm">
                <span className="font-bold text-slate-700">Release Forks</span>
              </div>
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
