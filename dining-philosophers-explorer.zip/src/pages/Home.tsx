import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play, BookOpen, ShieldAlert, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { PageWrapper, ContentCard } from '../components/Common';

export const Home = () => {
  return (
    <div className="min-h-screen pastel-gradient-1">
      <PageWrapper>
        {/* Hero Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-24 min-h-[70vh]">
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 backdrop-blur-sm text-primary rounded-full text-sm font-semibold border border-white/50"
            >
              <Zap className="w-4 h-4" />
              <span>Interactive OS Learning</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="font-display font-bold text-5xl md:text-7xl text-slate-900 leading-[1.1] tracking-tight"
            >
              Dining <br />
              <span className="text-primary">Philosophers</span> <br />
              Problem
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-slate-600 text-lg md:text-xl leading-relaxed max-w-lg"
            >
              Explore the classic synchronization challenge in Operating Systems through interactive visualizations and step-by-step guides.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-wrap gap-4"
            >
              <Link
                to="/problem"
                className="px-8 py-4 bg-primary text-white rounded-2xl font-bold flex items-center gap-2 hover:bg-primary/90 transition-all shadow-lg shadow-primary/20 hover:scale-105"
              >
                Start Learning
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/simulation"
                className="px-8 py-4 bg-white/80 backdrop-blur-sm text-slate-900 border border-white/50 rounded-2xl font-bold flex items-center gap-2 hover:bg-white transition-all hover:scale-105"
              >
                Live Simulation
                <Play className="w-5 h-5" />
              </Link>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full" />
            <div className="relative glass p-8 rounded-[40px] shadow-2xl border border-white/50">
              {/* SVG Illustration of Philosophers at a table */}
              <svg viewBox="0 0 400 400" className="w-full h-auto drop-shadow-xl">
                <circle cx="200" cy="200" r="120" fill="#f3f0ff" stroke="#e0f2fe" strokeWidth="4" />
                <circle cx="200" cy="200" r="100" fill="#ffffff" stroke="#e0f2fe" strokeWidth="2" />
                
                {/* Philosophers */}
                {[0, 72, 144, 216, 288].map((angle, i) => {
                  const x = 200 + 150 * Math.cos((angle - 90) * (Math.PI / 180));
                  const y = 200 + 150 * Math.sin((angle - 90) * (Math.PI / 180));
                  const colors = ['#a78bfa', '#60a5fa', '#f472b6', '#34d399', '#fbbf24'];
                  return (
                    <g key={i}>
                      <circle cx={x} cy={y} r="25" fill={colors[i]} />
                      <circle cx={x} cy={y - 5} r="10" fill="#ffffff" opacity="0.2" />
                    </g>
                  );
                })}
                
                {/* Forks */}
                {[36, 108, 180, 252, 324].map((angle, i) => {
                  const x1 = 200 + 80 * Math.cos((angle - 90) * (Math.PI / 180));
                  const y1 = 200 + 80 * Math.sin((angle - 90) * (Math.PI / 180));
                  const x2 = 200 + 110 * Math.cos((angle - 90) * (Math.PI / 180));
                  const y2 = 200 + 110 * Math.sin((angle - 90) * (Math.PI / 180));
                  return (
                    <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
                  );
                })}
                
                <text x="200" y="205" textAnchor="middle" className="font-bold text-2xl fill-slate-300">TABLE</text>
              </svg>
            </div>
          </motion.div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <ContentCard
            icon={BookOpen}
            title="Problem Statement"
            description="Understand the core constraints and the setup of the 5 philosophers and 5 forks."
            delay={0.1}
            className="bg-pastel-lavender/50 border-primary/10"
          />
          <ContentCard
            icon={ShieldAlert}
            title="Issues & Deadlocks"
            description="Learn why simple solutions fail and lead to circular wait and starvation."
            delay={0.2}
            className="bg-pastel-blue/50 border-secondary/10"
          />
          <ContentCard
            icon={Zap}
            title="Modern Solutions"
            description="Explore semaphores, resource hierarchy, and other advanced synchronization techniques."
            delay={0.3}
            className="bg-pastel-mint/50 border-emerald-100"
          />
        </div>
      </PageWrapper>
    </div>
  );
};
