import React from 'react';
import { Info, Users, Utensils, AlertCircle } from 'lucide-react';
import { PageWrapper, SectionHeader, ContentCard } from '../components/Common';
import { motion } from 'motion/react';

export const Problem = () => {
  return (
    <div className="min-h-screen pastel-gradient-2">
      <PageWrapper>
        <SectionHeader
          title="The Problem Statement"
          subtitle="A classic synchronization problem that illustrates the challenges of allocating shared resources among multiple processes."
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <ContentCard
            icon={Users}
            title="The Setup"
            description="Five silent philosophers sit at a round table with bowls of spaghetti. They spend their lives thinking and eating."
            className="bg-pastel-lavender/40"
          />
          <ContentCard
            icon={Utensils}
            title="The Resource"
            description="There are only five forks available. A philosopher needs two forks (left and right) to eat the spaghetti."
            className="bg-pastel-blue/40"
          />
          <ContentCard
            icon={AlertCircle}
            title="The Constraint"
            description="A philosopher can only pick up forks that are adjacent to them. They cannot speak to each other."
            className="bg-pastel-pink/40"
          />
        </div>

        <div className="glass rounded-[40px] p-8 md:p-12 border border-white/50 shadow-xl overflow-hidden relative">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full -mr-48 -mt-48 blur-3xl" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-slate-900">Visualizing the Setup</h2>
              <p className="text-slate-600 leading-relaxed text-lg">
                Imagine a circular table. Each position has a plate. Between each pair of adjacent plates, there is a single fork. 
                To eat, a philosopher must acquire both the fork to their left and the fork to their right.
              </p>
              <div className="space-y-6">
                {[
                  { id: 1, text: "Philosophers: P0, P1, P2, P3, P4" },
                  { id: 2, text: "Forks: F0, F1, F2, F3, F4" },
                  { id: 3, text: "Philosopher P(i) needs Fork F(i) and Fork F((i+1)%5)" }
                ].map((item) => (
                  <div key={item.id} className="flex items-center gap-4 group">
                    <div className="w-10 h-10 rounded-2xl bg-white shadow-sm flex items-center justify-center text-primary font-bold group-hover:bg-primary group-hover:text-white transition-all">
                      {item.id}
                    </div>
                    <p className="text-slate-700 font-medium">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white/40 backdrop-blur-sm rounded-[32px] p-8 flex items-center justify-center border border-white/50 shadow-inner">
              <svg viewBox="0 0 400 400" className="w-full max-w-sm h-auto drop-shadow-lg">
                {/* Table */}
                <circle cx="200" cy="200" r="100" fill="white" stroke="#e2e8f0" strokeWidth="4" />
                
                {/* Labels */}
                {[0, 72, 144, 216, 288].map((angle, i) => {
                  const px = 200 + 140 * Math.cos((angle - 90) * (Math.PI / 180));
                  const py = 200 + 140 * Math.sin((angle - 90) * (Math.PI / 180));
                  const fx = 200 + 90 * Math.cos((angle - 54) * (Math.PI / 180));
                  const fy = 200 + 90 * Math.sin((angle - 54) * (Math.PI / 180));
                  const colors = ['#a78bfa', '#60a5fa', '#f472b6', '#34d399', '#fbbf24'];
                  
                  return (
                    <g key={i}>
                      <circle cx={px} cy={py} r="22" fill={colors[i]} className="shadow-sm" />
                      <text x={px} y={py + 5} textAnchor="middle" fill="white" className="text-[10px] font-bold">P{i}</text>
                      
                      <rect x={fx - 4} y={fy - 12} width="8" height="24" rx="4" fill="#94a3b8" transform={`rotate(${angle + 36}, ${fx}, ${fy})`} />
                      <text x={fx + 18} y={fy + 5} className="text-[10px] fill-slate-400 font-bold">F{i}</text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
