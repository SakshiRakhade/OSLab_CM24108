import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Activity, Terminal } from 'lucide-react';
import { PageWrapper, SectionHeader } from '../components/Common';
import { motion, AnimatePresence } from 'motion/react';
import { Philosopher, Fork, PhilosopherState } from '../types';
import { cn } from '../lib/utils';

export const Simulation = () => {
  const [philosophers, setPhilosophers] = useState<Philosopher[]>([
    { id: 0, name: 'P0', state: 'Thinking', leftForkId: 0, rightForkId: 1 },
    { id: 1, name: 'P1', state: 'Thinking', leftForkId: 1, rightForkId: 2 },
    { id: 2, name: 'P2', state: 'Thinking', leftForkId: 2, rightForkId: 3 },
    { id: 3, name: 'P3', state: 'Thinking', leftForkId: 3, rightForkId: 4 },
    { id: 4, name: 'P4', state: 'Thinking', leftForkId: 4, rightForkId: 0 },
  ]);

  const [forks, setForks] = useState<Fork[]>([
    { id: 0, isHeld: false, heldBy: null },
    { id: 1, isHeld: false, heldBy: null },
    { id: 2, isHeld: false, heldBy: null },
    { id: 3, isHeld: false, heldBy: null },
    { id: 4, isHeld: false, heldBy: null },
  ]);

  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>(['Simulation ready. Click Start to begin.']);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-19), `${new Date().toLocaleTimeString()}: ${msg}`]);
  };

  const resetSimulation = () => {
    setIsRunning(false);
    setPhilosophers(prev => prev.map(p => ({ ...p, state: 'Thinking' })));
    setForks(prev => prev.map(f => ({ ...f, isHeld: false, heldBy: null })));
    setLogs(['Simulation reset.']);
  };

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setPhilosophers(prevPhils => {
        const newPhils = [...prevPhils];
        const philToUpdate = Math.floor(Math.random() * 5);
        const phil = newPhils[philToUpdate];

        if (phil.state === 'Thinking') {
          if (Math.random() > 0.5) {
            newPhils[philToUpdate] = { ...phil, state: 'Hungry' };
            addLog(`Philosopher ${phil.id} is hungry.`);
          }
        } else if (phil.state === 'Hungry') {
          // Try to pick up forks
          setForks(prevForks => {
            const newForks = [...prevForks];
            const leftFork = newForks[phil.leftForkId];
            const rightFork = newForks[phil.rightForkId];

            if (!leftFork.isHeld && !rightFork.isHeld) {
              newForks[phil.leftForkId] = { ...leftFork, isHeld: true, heldBy: phil.id };
              newForks[phil.rightForkId] = { ...rightFork, isHeld: true, heldBy: phil.id };
              newPhils[philToUpdate] = { ...phil, state: 'Eating' };
              addLog(`Philosopher ${phil.id} is eating.`);
              return newForks;
            }
            return prevForks;
          });
        } else if (phil.state === 'Eating') {
          if (Math.random() > 0.7) {
            setForks(prevForks => {
              const newForks = [...prevForks];
              newForks[phil.leftForkId] = { ...newForks[phil.leftForkId], isHeld: false, heldBy: null };
              newForks[phil.rightForkId] = { ...newForks[phil.rightForkId], isHeld: false, heldBy: null };
              newPhils[philToUpdate] = { ...phil, state: 'Thinking' };
              addLog(`Philosopher ${phil.id} finished eating and is now thinking.`);
              return newForks;
            });
          }
        }

        return newPhils;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning]);

  return (
    <div className="min-h-screen pastel-gradient-1">
      <PageWrapper>
        <SectionHeader
          title="Interactive Simulation"
          subtitle="Watch the philosophers interact with forks in real-time. Observe how they transition between states."
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Simulation Canvas */}
          <div className="lg:col-span-2 glass rounded-[48px] p-8 md:p-12 border border-white/50 shadow-2xl flex flex-col items-center justify-center min-h-[600px] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-white/20 -z-10" />
            
            <div className="relative w-full max-w-md aspect-square">
              {/* Table */}
              <div className="absolute inset-0 m-auto w-3/5 h-3/5 bg-white/80 backdrop-blur-sm rounded-full shadow-inner border-8 border-white/50 flex items-center justify-center">
                <div className="text-slate-400 font-bold tracking-[0.2em] text-xs">DINING TABLE</div>
              </div>

              {/* Philosophers */}
              {philosophers.map((phil, i) => {
                const angle = (i * 72 - 90) * (Math.PI / 180);
                const x = 50 + 40 * Math.cos(angle);
                const y = 50 + 40 * Math.sin(angle);
                
                const getPhilColor = (state: PhilosopherState) => {
                  switch (state) {
                    case 'Eating': return 'bg-pastel-mint shadow-pastel-mint/40';
                    case 'Hungry': return 'bg-pastel-peach shadow-pastel-peach/40';
                    default: return 'bg-pastel-blue shadow-pastel-blue/40';
                  }
                };
                
                return (
                  <motion.div
                    key={phil.id}
                    className={cn(
                      "absolute w-20 h-20 -ml-10 -mt-10 rounded-full flex flex-col items-center justify-center shadow-xl transition-all duration-500 border-4 border-white",
                      getPhilColor(phil.state)
                    )}
                    style={{ 
                      left: `${x}%`, 
                      top: `${y}%`
                    }}
                    animate={{ 
                      scale: phil.state === 'Eating' ? 1.15 : 1,
                      y: phil.state === 'Eating' ? [0, -5, 0] : 0
                    }}
                    transition={{
                      y: { repeat: Infinity, duration: 2 }
                    }}
                  >
                    <span className="text-slate-800 font-bold text-sm">{phil.name}</span>
                    <span className="text-slate-600 text-[8px] uppercase font-bold tracking-wider">{phil.state}</span>
                  </motion.div>
                );
              })}

              {/* Forks */}
              {forks.map((fork, i) => {
                const angle = (i * 72 - 54) * (Math.PI / 180);
                const x = 50 + 25 * Math.cos(angle);
                const y = 50 + 25 * Math.sin(angle);
                
                return (
                  <motion.div
                    key={fork.id}
                    className={cn(
                      "absolute w-2.5 h-10 -ml-1.25 -mt-5 rounded-full transition-all duration-300 border border-white/50",
                      fork.isHeld ? "bg-primary scale-125 shadow-lg shadow-primary/30" : "bg-slate-200"
                    )}
                    style={{ 
                      left: `${x}%`, 
                      top: `${y}%`,
                      transform: `rotate(${i * 72 + 36}deg)`
                    }}
                  />
                );
              })}
            </div>

            <div className="mt-16 flex flex-wrap justify-center gap-6">
              <button
                onClick={() => setIsRunning(!isRunning)}
                className={cn(
                  "px-10 py-4 rounded-[24px] font-bold flex items-center gap-3 transition-all hover:scale-105 active:scale-95 shadow-lg",
                  isRunning 
                    ? "bg-white text-slate-600 border border-slate-100" 
                    : "bg-primary text-white shadow-primary/30"
                )}
              >
                {isRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                {isRunning ? 'Pause Simulation' : 'Start Simulation'}
              </button>
              <button
                onClick={resetSimulation}
                className="px-10 py-4 bg-white border border-slate-100 text-slate-600 rounded-[24px] font-bold flex items-center gap-3 hover:bg-slate-50 transition-all hover:scale-105 active:scale-95 shadow-md"
              >
                <RotateCcw className="w-6 h-6" />
                Reset
              </button>
            </div>
          </div>

          {/* Sidebar: Status & Logs */}
          <div className="space-y-8">
            <div className="glass rounded-[32px] p-8 border border-white/50 shadow-xl">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary shadow-sm">
                  <Activity className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-900 text-xl">System Status</h3>
              </div>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Active Philosophers</span>
                  <span className="font-bold text-slate-900 bg-slate-100 px-3 py-1 rounded-lg">5</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Available Forks</span>
                  <span className="font-bold text-slate-900 bg-slate-100 px-3 py-1 rounded-lg">{forks.filter(f => !f.isHeld).length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Current State</span>
                  <span className={cn(
                    "font-bold px-4 py-1.5 rounded-full text-[10px] uppercase tracking-widest shadow-sm", 
                    isRunning ? "bg-green-100 text-green-600" : "bg-slate-100 text-slate-600"
                  )}>
                    {isRunning ? 'Running' : 'Paused'}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 rounded-[32px] p-8 border border-slate-800 shadow-2xl flex flex-col h-[400px]">
              <div className="flex items-center gap-4 mb-6 text-white">
                <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-primary">
                  <Terminal className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-lg">Event Log</h3>
              </div>
              <div className="flex-grow overflow-y-auto space-y-3 font-mono text-[11px] text-slate-400 custom-scrollbar pr-2">
                {logs.map((log, i) => (
                  <div key={i} className="border-l-2 border-primary/30 pl-3 py-1.5 bg-white/5 rounded-r-lg">
                    <span className="text-primary/60 mr-2">{log.split(': ')[0]}</span>
                    <span className="text-slate-200">{log.split(': ')[1]}</span>
                  </div>
                ))}
                <div ref={logEndRef} />
              </div>
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
