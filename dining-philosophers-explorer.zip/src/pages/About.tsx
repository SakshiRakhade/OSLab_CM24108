import React from 'react';
import { Mail, GraduationCap, Github, Linkedin, Calendar, MapPin } from 'lucide-react';
import { PageWrapper, SectionHeader } from '../components/Common';
import { motion } from 'motion/react';

export const About = () => {
  return (
    <div className="min-h-screen pastel-gradient-3">
      <PageWrapper>
        <SectionHeader
          title="About the Project"
          subtitle="This interactive educational platform was developed to help students visualize and understand complex Operating System concepts."
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-12">
            <div className="bg-white/60 backdrop-blur-md rounded-[40px] p-8 md:p-12 border border-white/50 shadow-xl">
              <h2 className="text-3xl font-bold text-slate-900 mb-8 tracking-tight">Project Overview</h2>
              <div className="space-y-8 text-slate-700 leading-relaxed text-lg">
                <p>
                  The Dining Philosophers problem is a classic synchronization problem in Operating Systems. 
                  It illustrates the challenges of allocating shared resources among multiple processes without causing deadlocks or starvation.
                </p>
                <p>
                  This project aims to provide a modern, interactive way to learn about this problem. 
                  Through visual diagrams, step-by-step explanations, and a live simulation, students can grasp the core concepts and the logic behind various solutions.
                </p>
                <p>
                  Built with modern web technologies like React, Tailwind CSS, and Framer Motion, this platform offers a smooth, PPT-style experience that is both engaging and informative.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="p-10 bg-pastel-blue/30 backdrop-blur-md rounded-[32px] border border-white/50 shadow-sm">
                <h3 className="font-bold text-xl text-slate-900 mb-6">Tech Stack</h3>
                <ul className="space-y-4 text-slate-700">
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-blue-400" />
                    <span className="font-medium">React 19</span> (Frontend Framework)
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-blue-400" />
                    <span className="font-medium">Tailwind CSS</span> (Styling)
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-blue-400" />
                    <span className="font-medium">Framer Motion</span> (Animations)
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-blue-400" />
                    <span className="font-medium">Lucide React</span> (Icons)
                  </li>
                </ul>
              </div>

              <div className="p-10 bg-pastel-mint/30 backdrop-blur-md rounded-[32px] border border-white/50 shadow-sm">
                <h3 className="font-bold text-xl text-slate-900 mb-6">Key Features</h3>
                <ul className="space-y-4 text-slate-700">
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    Interactive Simulation
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    Knowledge Check Quiz
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    Responsive Design
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    Smooth Page Transitions
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-white/60 backdrop-blur-md rounded-[40px] p-10 border border-white/50 shadow-xl text-center"
            >
              <div className="w-32 h-32 bg-pastel-lavender/40 rounded-full flex items-center justify-center mx-auto mb-8 shadow-sm border border-white/50">
                <GraduationCap className="w-16 h-16 text-indigo-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2 tracking-tight">Sakshi Rakhade</h3>
              <p className="text-indigo-600 font-bold text-sm mb-8 uppercase tracking-widest">Student Developer</p>
              
              <div className="space-y-5 text-left mb-10">
                <div className="flex items-center gap-4 text-slate-700 text-sm font-medium">
                  <div className="w-8 h-8 bg-white/60 rounded-xl flex items-center justify-center shadow-sm">
                    <Calendar className="w-4 h-4 text-slate-500" />
                  </div>
                  <span>Batch of 2026</span>
                </div>
                <div className="flex items-center gap-4 text-slate-700 text-sm font-medium">
                  <div className="w-8 h-8 bg-white/60 rounded-xl flex items-center justify-center shadow-sm">
                    <MapPin className="w-4 h-4 text-slate-500" />
                  </div>
                  <span>Engineering College</span>
                </div>
                <div className="flex items-center gap-4 text-slate-700 text-sm font-medium">
                  <div className="w-8 h-8 bg-white/60 rounded-xl flex items-center justify-center shadow-sm">
                    <Mail className="w-4 h-4 text-slate-500" />
                  </div>
                  <span>sakshi14506@gmail.com</span>
                </div>
              </div>

              <div className="flex justify-center gap-4">
                <a href="#" className="p-4 bg-white/60 rounded-2xl hover:bg-pastel-blue/40 hover:text-blue-700 transition-all shadow-sm border border-white/50">
                  <Github className="w-6 h-6" />
                </a>
                <a href="#" className="p-4 bg-white/60 rounded-2xl hover:bg-pastel-blue/40 hover:text-blue-700 transition-all shadow-sm border border-white/50">
                  <Linkedin className="w-6 h-6" />
                </a>
              </div>
            </motion.div>

            <div className="bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl">
              <h4 className="text-xl font-bold mb-4 tracking-tight">Need Help?</h4>
              <p className="text-slate-400 text-sm leading-relaxed mb-8">
                If you have any questions about the project or the concepts explained here, feel free to reach out.
              </p>
              <a
                href="mailto:sakshi14506@gmail.com"
                className="w-full py-4 bg-white text-slate-900 rounded-[20px] font-bold flex items-center justify-center gap-3 hover:bg-slate-100 transition-all shadow-lg hover:scale-105"
              >
                <Mail className="w-5 h-5" />
                Contact Me
              </a>
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  );
};
