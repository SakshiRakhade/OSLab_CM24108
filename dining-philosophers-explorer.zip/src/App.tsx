import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Pages
import { Home } from './pages/Home';
import { Problem } from './pages/Problem';
import { Working } from './pages/Working';
import { Issues } from './pages/Issues';
import { Solutions } from './pages/Solutions';
import { Simulation } from './pages/Simulation';
import { Applications } from './pages/Applications';
import { Advantages } from './pages/Advantages';
import { Quiz } from './pages/Quiz';
import { About } from './pages/About';

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/problem" element={<Problem />} />
          <Route path="/working" element={<Working />} />
          <Route path="/issues" element={<Issues />} />
          <Route path="/solutions" element={<Solutions />} />
          <Route path="/simulation" element={<Simulation />} />
          <Route path="/applications" element={<Applications />} />
          <Route path="/advantages" element={<Advantages />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
};

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <div className="flex-grow">
          <AnimatedRoutes />
        </div>
        <Footer />
      </div>
    </Router>
  );
}
